EXP = '''<details class="exp" style="position:relative">
      <summary class="btn" aria-label="Export build">Export<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"></path></svg></summary>
      <div class="panel" style="position:absolute;right:0;top:44px;width:360px;padding:8px;z-index:30;background:#14171B;box-shadow:0 14px 36px rgba(0,0,0,.6)">
        <p class="muted" style="margin:4px 12px 6px;font-size:12px">Export this build as…</p>
        <button class="xopt" type="button">
          <span style="display:flex;align-items:center;gap:8px"><span style="font-weight:600">Exiled Studio file</span><span class="badge b-ok">Default</span></span>
          <span class="muted" style="font-size:12px">.json · keeps everything: all stages, notes and lines with warnings</span>
        </button>
        <button class="xopt" type="button">
          <span style="font-weight:600">Path of Building</span>
          <span class="muted" style="font-size:12px">Share code or .xml · stages become item, skill and tree sets · lines with warnings kept as written</span>
        </button>
        <button class="xopt" type="button" disabled="disabled" aria-describedby="poe2why">
          <span style="display:flex;align-items:center;gap:8px"><span style="font-weight:600">Path of Exile 2 build file</span><span class="badge b-neutral">PoE2 only</span></span>
          <span id="poe2why" class="muted" style="font-size:12px">For importing into the game. Not available: this is a PoE1 build.</span>
        </button>
      </div>
    </details>'''
CSS = '''summary{list-style:none}summary::-webkit-details-marker{display:none}
.xopt{width:100%;display:flex;flex-direction:column;align-items:flex-start;gap:2px;padding:10px 12px;border:0;border-radius:8px;background:transparent;color:#E9E6DF;font:inherit;text-align:left;cursor:pointer;min-height:44px}
.xopt:hover{background:#22272F}.xopt:disabled{opacity:.55;cursor:not-allowed}.xopt:disabled:hover{background:transparent}
summary:focus-visible,.xopt:focus-visible{outline:2px solid #8DC1F2;outline-offset:2px}
'''
OLD = '<button class="btn" type="button">Export to PoB</button>'
def patch(s):
    if OLD in s:
        s = s.replace(OLD, EXP, 1)
    elif 'class="exp"' not in s:
        s = s.replace('<button class="btn" type="button" style="background:{{accent}};border-color:{{accent}};color:#1A1206">Save</button>', EXP + '\n    <button class="btn" type="button" style="background:{{accent}};border-color:{{accent}};color:#1A1206">Save</button>', 1)
    if '.xopt{' not in s:
        i = s.index('.btn:focus-visible'); s = s[:i] + CSS + s[i:]
    return s
