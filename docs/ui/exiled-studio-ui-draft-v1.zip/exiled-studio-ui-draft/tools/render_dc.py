import re, json, subprocess, sys, html
from html.parser import HTMLParser
VOID={'meta','input','link','br','img','hr','source'}
class N:
    def __init__(s,tag,attrs=None,text=None): s.tag=tag;s.attrs=attrs or [];s.text=text;s.kids=[]
class P(HTMLParser):
    def __init__(s):
        super().__init__(convert_charrefs=False); s.root=N('root'); s.st=[s.root]
    def handle_starttag(s,t,a):
        n=N(t,a); s.st[-1].kids.append(n)
        if t not in VOID: s.st.append(n)
    def handle_startendtag(s,t,a): s.st[-1].kids.append(N(t,a))
    def handle_endtag(s,t):
        for i in range(len(s.st)-1,0,-1):
            if s.st[i].tag==t: del s.st[i:]; return
    def handle_data(s,d): s.st[-1].kids.append(N(None,text=d))
    def handle_entityref(s,n): s.st[-1].kids.append(N(None,text='&'+n+';'))
    def handle_charref(s,n): s.st[-1].kids.append(N(None,text='&#'+n+';'))
def look(sc,p):
    p=p.strip()
    if p in('true','false'): return p=='true'
    v=sc
    for k in p.split('.'):
        v=v.get(k) if isinstance(v,dict) else None
    return v
def interp(s,sc):
    def r(m):
        v=look(sc,m.group(1))
        if v is True: return 'true'
        if v is False: return 'false'
        return '' if v is None else str(v)
    return re.sub(r'\{\{\s*([^}]+?)\s*\}\}',r,s)
def out(n,sc):
    if n.tag is None: return interp(n.text,sc)
    if n.tag=='sc-for':
        a=dict(n.attrs); lst=look(sc,a['list'].strip('{} ')) or []
        return ''.join(''.join(out(k,{**sc,a['as']:it,'$index':i}) for k in n.kids) for i,it in enumerate(lst))
    if n.tag=='sc-if':
        a=dict(n.attrs); v=look(sc,a['value'].strip('{} '))
        return ''.join(out(k,sc) for k in n.kids) if v else ''
    if n.tag in('helmet','x-dc','root'): return ''.join(out(k,sc) for k in n.kids if k.tag!='helmet')
    at=''.join(f' {k}' if v is None else f' {k}="{html.escape(interp(v,sc),quote=True)}"' for k,v in n.attrs if not k.startswith('hint-'))
    if n.tag in VOID: return f'<{n.tag}{at}>'
    return f'<{n.tag}{at}>'+''.join(out(k,sc) for k in n.kids)+f'</{n.tag}>'
src=open(sys.argv[1]).read()
xdc=re.search(r'<x-dc>(.*)</x-dc>',src,re.S).group(1)
style=re.search(r'<helmet>.*?<style>(.*?)</style>',xdc,re.S).group(1)
script=re.search(r'data-dc-script[^>]*>(.*?)</script>',src,re.S).group(1)
props=sys.argv[3] if len(sys.argv)>3 else '{}'
js="class DCLogic{constructor(p){this.props=p||{};this.state={}}setState(){}};"+script+";process.stdout.write(JSON.stringify(new Component("+props+").renderVals()))"
vals=json.loads(subprocess.run(['node','-e',js],capture_output=True,text=True,check=True).stdout)
p=P(); p.feed(xdc); body=out(p.root,vals).replace('min-height:960px','min-height:100vh')
open(sys.argv[2],'w').write(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><style>{style}</style></head><body>{body}</body></html>')
