from skills import *

# ---------- A: item cards ----------
bodyA = '''      <p class="muted" style="margin:-6px 0 0">One card per item. Gems joined by the gold bar are linked and work together; a break means they are not linked.</p>
      <div style="display:flex;flex-wrap:wrap;gap:16px;align-items:flex-start">
        <sc-for list="{{items}}" as="it" hint-placeholder-count="6">
          <section class="panel" style="flex:1 1 420px;min-width:0;display:flex;flex-direction:column">
            <div style="display:flex;align-items:center;gap:14px;padding:12px 16px;border-bottom:1px solid #2A2F37">
              <div style="width:52px;height:64px;flex:none;border:1.5px solid {{it.rc}};border-radius:6px;background:#0F1114;display:flex;align-items:center;justify-content:center">
''' + sock('it.mini') + '''
              </div>
              <div style="flex:1;min-width:0;display:flex;flex-direction:column">
                <span style="font-weight:700;color:{{it.rc}}">{{it.name}}</span>
                <span class="muted" style="font-size:12px">{{it.slot}} · {{it.base}}</span>
              </div>
              <span class="badge b-neutral">{{it.linkLabel}}</span>
            </div>
            <div style="padding:10px 16px 12px;display:flex;flex-direction:column;gap:6px">
              <sc-for list="{{it.groups}}" as="g" hint-placeholder-count="1">
                <div style="display:flex;gap:12px">
                  <div aria-hidden="true" style="width:4px;flex:none;border-radius:2px;margin:8px 0;background:{{g.rail}}"></div>
                  <div style="flex:1;min-width:0;display:flex;flex-direction:column">
                    <span class="muted" style="font-size:11px;text-transform:uppercase;letter-spacing:0.6px;padding-top:2px">{{g.label}}</span>
                    <sc-for list="{{g.gems}}" as="x" hint-placeholder-count="3">
                      <div style="display:flex;align-items:center;gap:10px;min-height:34px">
                        ''' + gem('x') + '''
                        <span style="font-weight:600">{{x.n}}</span>
                        <sc-if value="{{x.isMain}}" hint-placeholder-val="{{false}}"><span class="badge b-main">Main skill</span></sc-if>
                        <span class="muted" style="font-size:12px;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{x.note}}</span>
                        <span class="muted mono" style="font-size:11px">{{x.lv}}</span>
                      </div>
                    </sc-for>
                  </div>
                </div>
              </sc-for>
            </div>
          </section>
        </sc-for>
      </div>
'''
jsA = '''    const items = ITEMS.map((it) => ({ ...it, rc: RC[it.r], linkLabel: linkLabel(it), mini: sockets(it, 18, 14),
      groups: it.groups.map((g) => ({ rail: g.length > 1 ? '#B9A57A' : '#2A2F37', label: g.length > 1 ? 'Linked · ' + g.length + ' gems' : 'Not linked', gems: g.map(gemView) })) }));
    return { accent: acc, items };'''
build('SkillsA.dc.html', 'A', 'Item cards', 'Grouped by the item the gems sit in', bodyA, jsA, h=1240)

# ---------- B: socket layout ----------
bodyB = '''      <p class="muted" style="margin:-6px 0 0">Sockets are drawn the way they sit on the item. Numbers match the list beside them. Select an item to see its links in detail.</p>
      <div style="display:flex;flex-wrap:wrap;gap:16px;align-items:flex-start">
        <div style="flex:999 1 560px;min-width:0;display:flex;flex-wrap:wrap;gap:12px">
          <sc-for list="{{items}}" as="it" hint-placeholder-count="6">
            <button type="button" onClick="{{it.pick}}" aria-pressed="{{it.sel}}" class="panel" style="flex:1 1 300px;min-width:0;padding:14px 16px;text-align:left;font:inherit;color:#E9E6DF;cursor:pointer;display:flex;flex-direction:column;gap:12px;border-color:{{it.border}};background:{{it.bg}}">
              <span style="display:flex;align-items:baseline;gap:8px;flex-wrap:wrap"><span style="font-weight:700;color:{{it.rc}}">{{it.name}}</span><span class="muted" style="font-size:12px">{{it.slot}}</span><span style="flex:1"></span><span class="badge b-neutral">{{it.linkLabel}}</span></span>
              <span style="display:flex;gap:18px;align-items:flex-start">
                <span style="padding:10px;border-radius:8px;background:#0F1114;border:1px solid #2A2F37;display:flex">
''' + sock('it.big', inner='<span style="display:flex;width:100%;height:100%;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#0B0C0E">{{S.num}}</span>') + '''
                </span>
                <span style="flex:1;min-width:0;display:flex;flex-direction:column;gap:2px">
                  <sc-for list="{{it.flat}}" as="x" hint-placeholder-count="4">
                    <span style="display:flex;align-items:center;gap:8px;min-height:26px">
                      <span class="muted mono" style="font-size:11px;width:12px">{{x.num}}</span>
                      ''' + gem('x', 16) + '''
                      <span style="font-size:13px;font-weight:{{x.weight}};white-space:nowrap;overflow:hidden;text-overflow:ellipsis">{{x.n}}</span>
                    </span>
                  </sc-for>
                </span>
              </span>
            </button>
          </sc-for>
        </div>

        <aside class="panel" aria-labelledby="bsel" style="flex:1 1 320px;max-width:380px;min-width:0;padding:16px 18px;display:flex;flex-direction:column;gap:12px">
          <span class="muted" style="font-size:11px;text-transform:uppercase;letter-spacing:0.6px">Selected item</span>
          <h2 id="bsel" class="h" style="margin:0;font-size:18px;font-weight:600;color:{{cur.rc}}">{{cur.name}}</h2>
          <span class="muted" style="margin-top:-8px">{{cur.slot}} · {{cur.base}}</span>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            <span class="badge b-neutral">{{cur.linkLabel}}</span>
            <sc-for list="{{cur.colours}}" as="k" hint-placeholder-count="3"><span class="badge" style="background:#20242B;color:#E9E6DF"><span style="width:10px;height:10px;border-radius:50%;background:{{k.c}}"></span>{{k.t}}</span></sc-for>
          </div>
          <sc-for list="{{cur.groups}}" as="g" hint-placeholder-count="1">
            <div style="border-top:1px solid #2A2F37;padding-top:10px;display:flex;flex-direction:column;gap:6px">
              <span style="font-weight:600">{{g.label}}</span>
              <sc-for list="{{g.gems}}" as="x" hint-placeholder-count="3">
                <div style="display:flex;gap:8px;align-items:flex-start">''' + gem('x', 16) + '''<span style="display:flex;flex-direction:column"><span style="font-size:13px;font-weight:600">{{x.n}} <span class="muted mono" style="font-weight:400;font-size:11px">{{x.lv}}</span></span><span class="muted" style="font-size:12px">{{x.note}}</span></span></div>
              </sc-for>
            </div>
          </sc-for>
          <button class="btn" type="button" style="align-self:flex-start;min-height:44px">Edit sockets and gems</button>
        </aside>
      </div>
'''
jsB = '''    const sel = this.state.sel;
    const flatOf = (it) => { const f = []; it.groups.forEach((g) => g.forEach((x) => f.push(x))); return f; };
    const items = ITEMS.map((it, i) => ({ ...it, rc: RC[it.r], linkLabel: linkLabel(it), big: sockets(it, 46, 34),
      flat: flatOf(it).map((x, k) => ({ ...gemView(x), num: String(k + 1), weight: x.act ? '600' : '400' })),
      sel: i === sel ? 'true' : 'false', border: i === sel ? acc : '#2A2F37', bg: i === sel ? '#1C2027' : '#181B20', pick: () => this.setState({ sel: i }) }));
    const it = ITEMS[sel];
    const cnt = {}; flatOf(it).forEach((x) => { cnt[x.c] = (cnt[x.c] || 0) + 1; });
    const cur = { name: it.name, slot: it.slot, base: it.base, rc: RC[it.r], linkLabel: linkLabel(it),
      colours: Object.keys(cnt).map((k) => ({ c: C[k], t: cnt[k] + ' ' + AN[k].toLowerCase() })),
      groups: it.groups.map((g, gi) => ({ label: g.length > 1 ? 'Linked group ' + (gi + 1) + ' · ' + g.length + ' gems work together' : 'Socket on its own · not linked', gems: g.map(gemView) })) };
    return { accent: acc, items, cur };'''
build('SkillsB.dc.html', 'B', 'Socket layout', 'Sockets as they sit on each item', bodyB, jsB, h=1100)

# ---------- C: skill first ----------
bodyC = '''      <p class="muted" style="margin:-6px 0 0">Organised by what each linked group does. The item it sits in is secondary.</p>
      <div style="display:flex;flex-wrap:wrap;gap:16px;align-items:flex-start">
        <div role="listbox" aria-label="Skill groups" style="flex:1 1 360px;max-width:440px;min-width:0;display:flex;flex-direction:column;gap:8px">
          <sc-for list="{{groups}}" as="g" hint-placeholder-count="8">
            <button type="button" role="option" aria-selected="{{g.sel}}" onClick="{{g.pick}}" class="panel" style="padding:12px 14px;text-align:left;font:inherit;color:#E9E6DF;cursor:pointer;display:flex;flex-direction:column;gap:8px;border-color:{{g.border}};background:{{g.bg}}">
              <span style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <sc-for list="{{g.actives}}" as="x" hint-placeholder-count="1"><span style="display:flex;align-items:center;gap:6px">''' + gem('x', 18) + '''<span style="font-weight:700">{{x.n}}</span></span></sc-for>
                <sc-if value="{{g.isMain}}" hint-placeholder-val="{{false}}"><span class="badge b-main">Main skill</span></sc-if>
              </span>
              <span style="display:flex;flex-wrap:wrap;gap:6px">
                <sc-for list="{{g.sups}}" as="x" hint-placeholder-count="2"><span class="badge" style="background:#20242B;color:#C9CED6;font-weight:500">''' + gem('x', 12) + '''{{x.n}}</span></sc-for>
                <sc-if value="{{g.noSups}}" hint-placeholder-val="{{false}}"><span class="muted" style="font-size:12px">No supports linked</span></sc-if>
              </span>
              <span class="muted" style="font-size:12px">{{g.where}}</span>
            </button>
          </sc-for>
        </div>

        <section class="panel" aria-labelledby="cdet" style="flex:999 1 480px;min-width:0;display:flex;flex-direction:column">
          <div style="padding:16px 20px;border-bottom:1px solid #2A2F37;display:flex;flex-wrap:wrap;gap:10px;align-items:center">
            <h2 id="cdet" class="h" style="margin:0;font-size:20px;font-weight:600">{{cur.title}}</h2>
            <span class="muted">{{cur.where}}</span>
            <div style="flex:1"></div>
            <button class="btn" type="button">Set as main skill</button>
          </div>
          <div style="padding:8px 20px 4px;overflow-x:auto">
            <table style="width:100%;border-collapse:collapse;min-width:520px">
              <thead><tr class="muted" style="text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:0.6px"><th style="padding:10px 0;font-weight:600">Gem</th><th style="padding:10px 12px;font-weight:600">What it does here</th><th style="padding:10px 0;font-weight:600;text-align:right">{{cur.colHead}}</th></tr></thead>
              <tbody>
                <sc-for list="{{cur.rows}}" as="x" hint-placeholder-count="6">
                  <tr style="border-top:1px solid #23272E">
                    <td style="padding:10px 0"><span style="display:flex;align-items:center;gap:8px">''' + gem('x', 18) + '''<span style="font-weight:600">{{x.n}}</span><span class="muted mono" style="font-size:11px">{{x.lv}}</span></span></td>
                    <td class="muted" style="padding:10px 12px">{{x.note}}</td>
                    <td style="padding:10px 0;text-align:right;font-weight:600;color:{{x.dc}}">{{x.d}}</td>
                  </tr>
                </sc-for>
              </tbody>
            </table>
          </div>
          <sc-if value="{{cur.hasWarn}}" hint-placeholder-val="{{true}}">
            <div style="padding:12px 20px 18px;display:flex;flex-direction:column;gap:10px">
              <span class="h" style="font-weight:600">Interactions to check</span>
              <sc-for list="{{cur.warns}}" as="w" hint-placeholder-count="2">
                <div style="display:flex;gap:10px;padding:10px 12px;border-radius:8px;background:#221B12;border:1px solid #4A3518">
                  <span class="badge b-warn" style="align-self:flex-start">Check</span>
                  <span>{{w}}</span>
                </div>
              </sc-for>
            </div>
          </sc-if>
          <sc-if value="{{cur.noWarn}}" hint-placeholder-val="{{false}}"><p class="muted" style="margin:0;padding:12px 20px 18px">No conflicts found between these gems.</p></sc-if>
        </section>
      </div>
'''
jsC = '''    const DROP = { 'Spell Echo': '−31%', 'Lightning Penetration': '−24%', 'Inspiration': '−18%', 'Elemental Focus': '−27%', 'Controlled Destruction': '−12%' };
    const groups = [];
    ITEMS.forEach((it) => it.groups.forEach((g) => { const linked = g.length > 1; groups.push({ it, g, where: it.slot + ' · ' + it.name + (linked ? ' · ' + g.length + '-link' : ' · not linked'), isMain: g.some((x) => x.main) }); }));
    groups.sort((p, q) => (q.isMain ? 1 : 0) - (p.isMain ? 1 : 0));
    const sel = Math.min(this.state.sel, groups.length - 1);
    const view = groups.map((G, i) => ({ actives: G.g.filter((x) => x.act).map(gemView), sups: G.g.filter((x) => !x.act).map(gemView), noSups: !G.g.some((x) => !x.act),
      isMain: G.isMain, where: G.where, sel: i === sel ? 'true' : 'false', border: i === sel ? acc : '#2A2F37', bg: i === sel ? '#1C2027' : '#181B20', pick: () => this.setState({ sel: i }) }));
    const S = groups[sel];
    const warns = S.isMain ? ['Elemental Focus stops Arc from shocking. Your shock effect drops to 0% while it is linked.', 'Controlled Destruction lowers critical strike chance, and this build relies on crits (68%).'] : [];
    const cur = { title: S.g.filter((x) => x.act).map((x) => x.n).join(' · '), where: S.where,
      colHead: S.isMain ? 'DPS without it' : 'Role',
      rows: S.g.map((x) => ({ ...gemView(x), note: x.note || (x.act ? 'Skill' : 'Support'), d: S.isMain ? (x.act ? 'Main' : (DROP[x.n] || '—')) : (x.act ? 'Skill' : 'Support'), dc: S.isMain && !x.act ? '#F5BE6B' : '#C9CED6' })),
      warns, hasWarn: warns.length > 0, noWarn: warns.length === 0 };
    return { accent: acc, groups: view, cur };'''
build('SkillsC.dc.html', 'C', 'Skill first', 'Grouped by what each linked group does', bodyC, jsC, h=1100)

# ---------- D: compact table ----------
bodyD = '''      <div style="display:flex;flex-wrap:wrap;gap:8px">
        <sc-for list="{{summary}}" as="k" hint-placeholder-count="5"><span class="badge b-neutral" style="font-size:13px;padding:4px 10px">{{k}}</span></sc-for>
      </div>
      <section class="panel" style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;min-width:980px">
          <thead><tr class="muted" style="text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:0.6px">
            <th style="padding:12px 16px;font-weight:600;width:220px">Item</th><th style="padding:12px 12px;font-weight:600;width:170px">Sockets and links</th><th style="padding:12px 12px;font-weight:600">Gems · boxed gems are linked</th><th style="padding:12px 16px;font-weight:600;width:150px">Colours</th>
          </tr></thead>
          <tbody>
            <sc-for list="{{items}}" as="it" hint-placeholder-count="6">
              <tr style="border-top:1px solid #23272E;vertical-align:middle">
                <td style="padding:12px 16px"><div style="font-weight:700;color:{{it.rc}}">{{it.name}}</div><div class="muted" style="font-size:12px">{{it.slot}}</div></td>
                <td style="padding:12px 12px">
                  <div style="display:flex;align-items:center" role="img" aria-label="{{it.linkLabel}}">
                    <sc-for list="{{it.dots}}" as="d" hint-placeholder-count="4"><span style="width:14px;height:14px;border-radius:50%;background:{{d.c}};border:2px solid #0B0C0E;flex:none"></span><span style="width:12px;height:4px;flex:none;background:{{d.bar}};border-radius:2px"></span></sc-for>
                  </div>
                  <div class="muted" style="font-size:11px;margin-top:4px">{{it.linkLabel}}</div>
                </td>
                <td style="padding:10px 12px">
                  <div style="display:flex;flex-wrap:wrap;gap:8px">
                    <sc-for list="{{it.groups}}" as="g" hint-placeholder-count="2">
                      <div style="display:flex;flex-wrap:wrap;gap:4px 10px;align-items:center;padding:5px 10px;border-radius:8px;border:1.5px {{g.style}} {{g.border}};background:{{g.bg}}">
                        <sc-for list="{{g.gems}}" as="x" hint-placeholder-count="3"><span style="display:flex;align-items:center;gap:5px;font-size:13px;font-weight:{{x.weight}}">''' + gem('x', 14) + '''{{x.n}}<sc-if value="{{x.isMain}}" hint-placeholder-val="{{false}}"><span class="badge b-main" style="font-size:10px;padding:0 6px">Main</span></sc-if></span></sc-for>
                      </div>
                    </sc-for>
                  </div>
                </td>
                <td style="padding:12px 16px"><div style="display:flex;flex-wrap:wrap;gap:6px"><sc-for list="{{it.colours}}" as="k" hint-placeholder-count="2"><span class="badge" style="background:#20242B;color:#E9E6DF"><span style="width:9px;height:9px;border-radius:50%;background:{{k.c}}"></span>{{k.t}}</span></sc-for></div></td>
              </tr>
            </sc-for>
          </tbody>
        </table>
      </section>
      <p class="muted" style="margin:0;font-size:12px">Built for a quick check of the whole setup: one row per item, nothing to open.</p>
'''
jsD = '''    let nAct = 0, nSup = 0, nSock = 0, six = 0;
    const items = ITEMS.map((it) => {
      const flat = []; it.groups.forEach((g) => g.forEach((x, k) => flat.push({ x, linkNext: k < g.length - 1 })));
      const cnt = {}; flat.forEach(({ x }) => { cnt[x.c] = (cnt[x.c] || 0) + 1; x.act ? nAct++ : nSup++; }); nSock += flat.length;
      if (it.groups.some((g) => g.length >= 6)) six++;
      return { ...it, rc: RC[it.r], linkLabel: linkLabel(it),
        dots: flat.map((f, i) => ({ c: C[f.x.c], bar: f.linkNext ? '#B9A57A' : 'transparent' })),
        groups: it.groups.map((g) => ({ style: g.length > 1 ? 'solid' : 'dashed', border: g.length > 1 ? '#5C5138' : '#3A414C', bg: g.length > 1 ? '#1F1D17' : 'transparent', gems: g.map((x) => ({ ...gemView(x), weight: x.act ? '600' : '400' })) })),
        colours: Object.keys(cnt).map((k) => ({ c: C[k], t: cnt[k] + ' ' + AN[k].slice(0, 3) })) };
    });
    const summary = [nAct + ' skills', nSup + ' supports', nSock + ' sockets', '0 empty', six + ' six-link'];
    return { accent: acc, items, summary };'''
build('SkillsD.dc.html', 'D', 'Compact table', 'Every item and gem on one screen', bodyD, jsD, h=960)
print('built')
