import os
import re
from skills import *
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'build_skills.py')).read()
ns = {}
exec(src.split("build('SkillsA.dc.html'")[0].replace('from skills import *',''), globals(), ns)
bodyA, jsA = ns['bodyA'], ns['jsA']
mB = src.index('# ---------- D: compact table ----------')
ns2 = {}
exec(src[mB:].split("build('SkillsD.dc.html'")[0], globals(), ns2)
bodyD, jsD = ns2['bodyD'], ns2['jsD']
ns3 = {}
cs = src.index('# ---------- C: skill first ----------')
exec(src[cs:mB].split("build('SkillsC.dc.html'")[0], globals(), ns3)
bodyC, jsC = ns3['bodyC'], ns3['jsC']

# --- link groups to the breakdown page ---
bodyA2 = bodyA.replace('<p class="muted" style="margin:-6px 0 0">One card per item. Gems joined by the gold bar are linked and work together; a break means they are not linked.</p>\n','')
bodyA2 = bodyA2.replace('<span class="muted" style="font-size:11px;text-transform:uppercase;letter-spacing:0.6px;padding-top:2px">{{g.label}}</span>',
  '<span style="display:flex;align-items:center;gap:10px;padding-top:2px"><span class="muted" style="font-size:11px;text-transform:uppercase;letter-spacing:0.6px">{{g.label}}</span><sc-if value="{{g.linked}}" hint-placeholder-val="{{true}}"><a href="SkillGroup.dc.html" style="font-size:12px;font-weight:600">See how they interact</a></sc-if></span>')
bodyD2 = bodyD.replace('<div style="display:flex;flex-wrap:wrap;gap:4px 10px;align-items:center;padding:5px 10px;border-radius:8px;border:1.5px {{g.style}} {{g.border}};background:{{g.bg}}">',
  '<a href="SkillGroup.dc.html" aria-label="Open breakdown of this group" style="text-decoration:none;color:#E9E6DF;display:flex;flex-wrap:wrap;gap:4px 10px;align-items:center;padding:5px 10px;border-radius:8px;border:1.5px {{g.style}} {{g.border}};background:{{g.bg}}">')
# close the converted div -> a  (the pill's closing div is right after its inner sc-for)
bodyD2 = bodyD2.replace('</span></sc-for>\n                      </div>\n                    </sc-for>','</span></sc-for>\n                      </a>\n                    </sc-for>')
bodyD2 = bodyD2.replace('Built for a quick check of the whole setup: one row per item, nothing to open.','Select a boxed group to see how its gems interact.')

toggle = '''      <div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center">
        <div role="group" aria-label="Layout" style="display:flex;border:1px solid #3A414C;border-radius:8px;overflow:hidden">
          <button class="tab" type="button" aria-pressed="{{cardsOn}}" onClick="{{showCards}}" style="border:0;border-radius:0;background:{{cardsBg}};color:{{cardsFg}}">Cards</button>
          <button class="tab" type="button" aria-pressed="{{tableOn}}" onClick="{{showTable}}" style="border:0;border-radius:0;background:{{tableBg}};color:{{tableFg}}">Table</button>
        </div>
        <span class="muted">{{viewHint}}</span>
      </div>
'''
body = toggle + '<sc-if value="{{isCards}}" hint-placeholder-val="{{true}}">\n' + bodyA2 + '</sc-if>\n<sc-if value="{{isTable}}" hint-placeholder-val="{{false}}">\n' + bodyD2 + '</sc-if>\n'

jsA_ = jsA.replace("label: g.length > 1 ? 'Linked · ' + g.length + ' gems' : 'Not linked',", "label: g.length > 1 ? 'Linked · ' + g.length + ' gems' : 'Not linked', linked: g.length > 1,").replace('return { accent: acc, items };', 'const cardItems = items;')
jsD_ = jsD.replace('const items = ITEMS.map', 'const tableItems = ITEMS.map').replace('return { accent: acc, items, summary };', '')
js = jsA_ + '\n' + jsD_ + '''
    const view = this.state.view ?? this.props.view ?? 'Cards';
    const isCards = view === 'Cards';
    return { accent: acc, cardItems, tableItems, summary, isCards, isTable: !isCards,
      cardsOn: isCards ? 'true' : 'false', tableOn: isCards ? 'false' : 'true',
      cardsBg: isCards ? '#2C323B' : 'transparent', cardsFg: isCards ? '#E9E6DF' : '#C9CED6',
      tableBg: isCards ? 'transparent' : '#2C323B', tableFg: isCards ? '#C9CED6' : '#E9E6DF',
      viewHint: isCards ? 'One card per item. A gold bar joins linked gems.' : 'One row per item. Boxed gems are linked.',
      showCards: () => this.setState({ view: 'Cards' }), showTable: () => this.setState({ view: 'Table' }) };'''
body = body.replace('{{items}}" as="it" hint-placeholder-count="6">\n          <section', '{{cardItems}}" as="it" hint-placeholder-count="6">\n          <section', 1)
body = body.replace('<sc-for list="{{items}}" as="it" hint-placeholder-count="6">\n              <tr', '<sc-for list="{{tableItems}}" as="it" hint-placeholder-count="6">\n              <tr', 1)
assert '{{items}}' not in body, 'items left'
build('SkillsA.dc.html', '', 'Skills', 'Switch between cards and table while the layout is decided', body, js, h=1240)
s = open(os.path.join(PROJ, 'SkillsA.dc.html')).read()
s = s.replace('"$preview"', '"view":{"editor":"enum","options":["Cards","Table"],"default":"Cards"},"$preview"', 1)
open(os.path.join(PROJ, 'SkillsA.dc.html'), 'w').write(s)

# --- group breakdown page (from C) ---
bodyG = bodyC.replace('<p class="muted" style="margin:-6px 0 0">Organised by what each linked group does. The item it sits in is secondary.</p>',
  '<nav aria-label="Breadcrumb" class="muted" style="font-size:13px;margin-top:-6px"><a href="SkillsA.dc.html">Skills</a> › {{cur.title}}</nav>')
bodyG = bodyG.replace('<div role="listbox" aria-label="Skill groups" style="flex:1 1 360px;max-width:440px;',
  '<div role="listbox" aria-label="Skill groups" style="flex:1 1 300px;max-width:360px;')
bodyG = bodyG.replace('<div style="flex:1"></div>\n            <button class="btn" type="button">Set as main skill</button>',
  '<div style="flex:1"></div>\n            <button class="btn" type="button">Set as main skill</button>\n            <a class="btn" href="ItemEditor.dc.html">Edit gems</a>')
build('SkillGroup.dc.html', '<span class="badge b-neutral">Group breakdown</span>', 'Skill group breakdown', 'How the linked gems in one group work together', bodyG, jsC, h=1000)
print('ok')
