import json, os
PROJ = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'canvas-source', 'project')
HEAD = open(os.path.join(PROJ, 'Equipment.dc.html')).read()
import re
FONTS = re.search(r'(<link rel="preconnect".*?rel="stylesheet">)', HEAD, re.S).group(1)
CSS = r'''body{margin:0;background:#101215}
a{color:#F0B45A}a:hover{color:#FFD08A}
.es{font-family:Inter,system-ui,sans-serif;color:#E9E6DF;background:#101215;font-size:14px;line-height:1.45}
.h{font-family:'Space Grotesk',Inter,sans-serif}
.mono{font-family:'JetBrains Mono',ui-monospace,monospace}
.panel{background:#181B20;border:1px solid #2A2F37;border-radius:10px}
.muted{color:#A3A9B3}
.btn{min-height:36px;padding:0 14px;border-radius:8px;border:1px solid #3A414C;background:#20242B;color:#E9E6DF;font:inherit;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:8px;text-decoration:none}
.nav{min-height:44px;display:flex;align-items:center;gap:10px;padding:0 12px;border-radius:8px;color:#C9CED6;text-decoration:none;font-weight:500}
.badge{display:inline-flex;align-items:center;gap:6px;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:600;white-space:nowrap}
.b-ok{background:#1D2B22;color:#A3DDB2}
.b-warn{background:#3A2A12;color:#F5BE6B}
.b-info{background:#16263A;color:#8DC1F2}
.b-neutral{background:#252A32;color:#C9CED6}
.b-main{background:#2E2410;color:#F0B45A}
.tab{min-height:36px;padding:0 14px;border-radius:8px;border:1px solid #2F353E;background:#1C1F25;color:#C9CED6;font:inherit;font-weight:600;cursor:pointer}
.sock{position:absolute;border-radius:50%;box-sizing:border-box;border:2px solid #0B0C0E}
.lnk{position:absolute;background:#B9A57A;border-radius:3px}
.btn:focus-visible,.nav:focus-visible,.tab:focus-visible{outline:2px solid #8DC1F2;outline-offset:2px}
'''
SHELL_TOP = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>%(title)s</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
''' + FONTS + '''
<style>
''' + CSS + '''%(css)s</style>
</helmet>
<div class="es" style="width:100%%;min-height:960px;display:flex;flex-direction:column">
  <header style="display:flex;flex-wrap:wrap;align-items:center;gap:12px;padding:10px 20px;border-bottom:1px solid #2A2F37;background:#14171B">
    <a href="Main.dc.html" style="display:flex;align-items:center;gap:10px;text-decoration:none;color:#E9E6DF">
      <svg width="26" height="26" viewBox="0 0 28 28" fill="none" stroke="{{accent}}" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M5 8c6 0 12 12 18 12M5 20c6 0 12-12 18-12M5 14h18"></path></svg>
      <span class="h" style="font-weight:700;font-size:16px">Exiled Studio</span>
    </a>
    <span aria-hidden="true" class="muted">/</span>
    <span style="font-weight:600">Arc Elementalist</span>
    <button class="btn" type="button" aria-haspopup="listbox" aria-expanded="false" style="border-color:{{accent}};gap:10px"><span class="muted" style="font-weight:500;font-size:12px;text-transform:uppercase;letter-spacing:0.6px">Stage</span><span>Mapping</span><span class="muted" style="font-weight:500">Lv 85–94</span><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"></path></svg></button>
    <span class="badge b-warn">Partial · 3 warnings</span>
    <div style="flex:1"></div>
    <span class="badge b-ok" role="status">Up to date</span>
    %(export)s
    <button class="btn" type="button" style="background:{{accent}};border-color:{{accent}};color:#1A1206">Save</button>
  </header>
  <div style="flex:1;display:flex;flex-wrap:wrap">
    <nav aria-label="Build sections" style="flex:1 1 200px;max-width:220px;padding:16px 12px;border-right:1px solid #2A2F37;display:flex;flex-direction:column;gap:2px;background:#13161A">
      <a class="nav" href="Workspace.dc.html">Dashboard</a>
      <a class="nav" href="Equipment.dc.html">Equipment</a>
      <a class="nav" href="SkillsA.dc.html" aria-current="page" style="background:#22272F;color:#E9E6DF">Skills <span class="muted" style="margin-left:auto;font-size:12px">5 groups</span></a>
      <a class="nav" href="#tree">Passive tree <span class="muted" style="margin-left:auto;font-size:12px">104 pts</span></a>
      <a class="nav" href="#config">Configuration</a>
      <a class="nav" href="ImportReview.dc.html">Warnings <span class="badge b-warn" style="margin-left:auto">3</span></a>
    </nav>
    <main style="flex:999 1 560px;min-width:0;padding:20px 24px;display:flex;flex-direction:column;gap:16px">
      <div style="display:flex;flex-wrap:wrap;gap:10px 16px;align-items:center">
        <h1 class="h" style="margin:0;font-size:24px;font-weight:600">Skills</h1>
        %(badge)s
        <span class="muted">%(sub)s</span>
        <div style="flex:1"></div>
        <div class="muted" style="display:flex;flex-wrap:wrap;gap:12px;font-size:12px;align-items:center">
          <span style="display:flex;align-items:center;gap:5px"><span style="width:12px;height:12px;border-radius:50%%;background:#E0796A"></span>Strength</span>
          <span style="display:flex;align-items:center;gap:5px"><span style="width:12px;height:12px;border-radius:50%%;background:#7FC27A"></span>Dexterity</span>
          <span style="display:flex;align-items:center;gap:5px"><span style="width:12px;height:12px;border-radius:50%%;background:#6FA6E6"></span>Intelligence</span>
          <span style="display:flex;align-items:center;gap:5px"><span style="width:12px;height:12px;border-radius:50%%;background:#D6D9DE"></span>White</span>
          <span style="display:flex;align-items:center;gap:5px"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l9 5v10l-9 5-9-5V7z" fill="#A3A9B3"></path></svg>Skill</span>
          <span style="display:flex;align-items:center;gap:5px"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="7" fill="#A3A9B3"></circle></svg>Support</span>
        </div>
      </div>
'''
SHELL_BOT = '''      <p class="muted" style="margin:0;font-size:12px">Sample data. Gem pictures are simple shapes: a hexagon is a skill, a circle is a support; colour is the gem's attribute.</p>
    </main>
  </div>
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"accent":{"editor":"color","default":"#E8A33D","options":["#E8A33D","#7FB2E5","#9FD39B","#D98A6A"]},"$preview":{"width":1440,"height":%(h)d}}'>
''' + r'''class Component extends DCLogic {
  constructor(props) { super(props); this.state = { sel: 0 }; }
  renderVals() {
    const C = { r: '#E0796A', g: '#7FC27A', b: '#6FA6E6', w: '#D6D9DE' };
    const AN = { r: 'Strength', g: 'Dexterity', b: 'Intelligence', w: 'White' };
    const RC = { r: '#F2D97A', u: '#E39A6E' };
    const s = (n, c, lv, note) => ({ n, c, act: false, lv: lv || '20/20', note: note || '' });
    const a = (n, c, lv, note, main) => ({ n, c, act: true, lv: lv || '20/20', note: note || '', main: !!main });
    const ITEMS = [
      { slot: 'Body armour', name: 'Cherrubim’s Maleficence', base: 'Unique body armour', r: 'u', layout: 'body', groups: [[a('Arc', 'b', '21/20', 'Main skill', true), s('Spell Echo', 'b', '20/20', 'Repeats each cast; casts faster'), s('Lightning Penetration', 'b', '20/20', 'Enemies resist less lightning'), s('Inspiration', 'r', '20/20', 'Cheaper, more elemental damage'), s('Elemental Focus', 'g', '20/20', 'More damage; cannot inflict ailments'), s('Controlled Destruction', 'b', '20/20', 'More spell damage; less critical chance')]] },
      { slot: 'Helmet', name: 'Storm Crown', base: 'Hubris Circlet', r: 'r', layout: 'sq', groups: [[a('Wrath', 'b', '21/20', 'Aura'), a('Herald of Thunder', 'b', '20/20', 'Buff'), s('Enlighten', 'b', '3/0', 'Reserves less mana'), a('Arrogance', 'r', '20/20', 'Reserves life instead')]] },
      { slot: 'Gloves', name: 'Grim Grip', base: 'Sorcerer Gloves', r: 'r', layout: 'sq', groups: [[a('Arcanist Brand', 'b', '20/20', 'Triggers the spells linked to it'), a('Frost Bomb', 'b'), a('Conductivity', 'b', '20/20', 'Curse')], [a('Frostblink', 'b', '20/20', 'Movement')]] },
      { slot: 'Boots', name: 'Gale Tread', base: 'Sorcerer Boots', r: 'r', layout: 'sq', groups: [[a('Flame Dash', 'b', '20/20', 'Movement'), s('Faster Casting', 'b')], [a('Steelskin', 'r', '20/20', 'Guard'), s('Cast when Damage Taken', 'r', '1/0')]] },
      { slot: 'Weapon', name: 'Doom Song', base: 'Imbued Wand', r: 'r', layout: 'col', groups: [[a('Orb of Storms', 'b'), s('Power Charge On Critical', 'b'), s('Increased Critical Strikes', 'b')]] },
      { slot: 'Off-hand', name: 'Mind Ward', base: 'Titanium Spirit Shield', r: 'r', layout: 'sq3', groups: [[a('Clarity', 'b', '1/0', 'Aura')], [a('Vaal Discipline', 'b')], [a('Portal', 'w', '1/0')]] }
    ];
    const POS = { body: [[0,0],[1,0],[1,1],[0,1],[0,2],[1,2]], sq: [[0,0],[1,0],[1,1],[0,1]], sq3: [[0,0],[1,0],[1,1]], col: [[0,0],[0,1],[0,2]] };
    const sockets = (it, cell, d) => {
      const flat = []; it.groups.forEach((g, gi) => g.forEach((x, k) => flat.push({ ...x, gi, linkNext: k < g.length - 1 })));
      const pos = POS[it.layout];
      const socks = flat.map((x, i) => ({ left: pos[i][0] * cell + 'px', top: pos[i][1] * cell + 'px', size: d + 'px', bg: C[x.c], num: String(i + 1), label: (i + 1) + '. ' + x.n }));
      const links = [];
      flat.forEach((x, i) => { if (!x.linkNext) return; const [c1, r1] = pos[i], [c2, r2] = pos[i + 1]; const t = Math.max(4, Math.round(d * 0.28));
        if (r1 === r2) links.push({ left: (Math.min(c1, c2) * cell + d / 2) + 'px', top: (r1 * cell + d / 2 - t / 2) + 'px', w: cell + 'px', h: t + 'px' });
        else links.push({ left: (c1 * cell + d / 2 - t / 2) + 'px', top: (Math.min(r1, r2) * cell + d / 2) + 'px', w: t + 'px', h: cell + 'px' }); });
      const cols = Math.max(...pos.slice(0, flat.length).map((p) => p[0])) + 1, rows = Math.max(...pos.slice(0, flat.length).map((p) => p[1])) + 1;
      return { socks, links, w: ((cols - 1) * cell + d) + 'px', h: ((rows - 1) * cell + d) + 'px' };
    };
    const linkLabel = (it) => { const n = it.groups.reduce((m, g) => Math.max(m, g.length), 0); const tot = it.groups.reduce((m, g) => m + g.length, 0); return tot + ' sockets · ' + (n > 1 ? n + '-link' : 'no links'); };
    const gemView = (x) => ({ ...x, color: C[x.c], aria: (x.act ? 'Skill gem' : 'Support gem') + ', ' + AN[x.c], isAct: x.act, isSup: !x.act, isMain: !!x.main, hasNote: !!x.note });
    const acc = this.props.accent ?? '#E8A33D';
''' + '%(js)s' + r'''
  }
}
</script>
</body>
</html>
'''
GEM_SVG = '''<sc-if value="{{%(v)s.isAct}}" hint-placeholder-val="{{true}}"><svg width="%(s)d" height="%(s)d" viewBox="0 0 24 24" role="img" aria-label="{{%(v)s.aria}}" style="flex:none"><path d="M12 2l9 5v10l-9 5-9-5V7z" fill="{{%(v)s.color}}" stroke="#0B0C0E" stroke-width="1.2"></path></svg></sc-if><sc-if value="{{%(v)s.isSup}}" hint-placeholder-val="{{false}}"><svg width="%(s)d" height="%(s)d" viewBox="0 0 24 24" role="img" aria-label="{{%(v)s.aria}}" style="flex:none"><circle cx="12" cy="12" r="7.5" fill="{{%(v)s.color}}" stroke="#0B0C0E" stroke-width="1.2"></circle></svg></sc-if>'''
def gem(v, s=22): return GEM_SVG % {'v': v, 's': s}
SOCK = '''<div style="position:relative;width:{{%(v)s.w}};height:{{%(v)s.h}};flex:none" role="img" aria-label="Socket layout">
  <sc-for list="{{%(v)s.links}}" as="L" hint-placeholder-count="3"><div class="lnk" style="left:{{L.left}};top:{{L.top}};width:{{L.w}};height:{{L.h}}"></div></sc-for>
  <sc-for list="{{%(v)s.socks}}" as="S" hint-placeholder-count="4"><div class="sock" title="{{S.label}}" style="left:{{S.left}};top:{{S.top}};width:{{S.size}};height:{{S.size}};background:{{S.bg}}%(extra)s">%(inner)s</div></sc-for>
</div>'''
def sock(v, inner='', extra=''): return SOCK % {'v': v, 'inner': inner, 'extra': extra}

def build(fname, letter, vname, sub, body, js, css='', h=960):
    top = SHELL_TOP.replace('%%', '%')
    from export import EXP, CSS as XCSS
    top = top.replace('%(export)s', EXP)
    top = top.replace('.btn:focus-visible', XCSS + '.btn:focus-visible', 1)
    for k, v in {'title': vname, 'css': css, 'badge': letter, 'sub': sub}.items(): top = top.replace('%(' + k + ')s', v)
    out = top + body + SHELL_BOT.replace('%(h)d', str(h)).replace('%(js)s', js)
    open(os.path.join(PROJ, fname), 'w').write(out)
