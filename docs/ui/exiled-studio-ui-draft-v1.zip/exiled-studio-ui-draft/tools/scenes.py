import sys
from film import run
C='#'  # unused
SC={}
SC['s0']=('Title',3.6,{'showcur':False,'cursor':[(0,(800,450))]})
SC['s1']=('Main',9.4,{
 'init':["document.getElementById('code').value=''"],
 'caps':[(0.3,'<b>1</b>Start: pick a task. Here, import a build from Path of Building.'),
         (3.9,'Recent builds show their status and the game-data version each one uses.'),
         (6.6,'Paste the code, then import.')],
 'ring':[(0.5,3.7,'section.panel:has-text("Import from Path of Building")'),(4.0,6.4,'table')],
 'cursor':[(0,(1100,620)),(1.2,('#code',(0.3,0.4))),(4.6,('span.badge:has-text("Partial · 3 lines held")',(0.5,0.6))),(5.8,('span.badge:has-text("Calcs not supported yet")',(0.5,0.6))),(7.6,'a:has-text("Import build")')],
 'clicks':[1.3,7.8],
 'type':[(1.5,3.3,'#code','eNrtfQt327aS8O_ru6mGd2Xl4Kq9Vbm0Qx...')]})
SC['s2']=('ImportReview',10.6,{
 'caps':[(0.3,'<b>2</b>The import result: what was read, matched to game stats, adapted, or held.'),
         (3.8,'Lines it cannot read are held: kept and shown, never dropped.'),
         (6.9,'It also says which parts of the build can be calculated.'),
         (8.9,'Open the build in the workspace.')],
 'ring':[(0.6,3.6,'div[style*="repeat(4"]'),(3.8,6.7,'section.panel:has-text("Lines to review")'),(6.9,8.8,'section.panel:has-text("What can be calculated")')],
 'cursor':[(0,(900,500)),(1.6,('span:text-is("405")',(0.6,0.6))),(2.8,('span:text-is("3")',(0.6,0.6))),(4.6,'span.badge:has-text("LINE_NO_TEMPLATE")'),(5.8,'span.badge:has-text("LINE_AMBIGUOUS")'),(7.6,'span.badge:has-text("Not yet")'),(9.4,'a:has-text("Open in workspace")')],
 'clicks':[9.6]})
SC['s3']=('Workspace',10.4,{
 'caps':[(0.3,'<b>3</b>The workspace: offence, defence, items and skills in one view.'),
         (1.9,'Switch between Guided and Workspace mode at any time.'),
         (3.7,'Each number says whether it is exact, partial, or not supported yet.'),
         (6.3,'Items with held lines are flagged.'),
         (8.2,'Select Total DPS to see why it is that number.')],
 'ring':[(1.9,3.5,'div[role="group"]'),(3.7,6.1,'section.panel:has-text("Offence")'),(6.3,8.0,'section.panel:has-text("Equipped items")')],
 'cursor':[(0,(800,700)),(2.6,'button:has-text("Workspace")'),(4.6,'span.badge:has-text("Partial") >> nth=1'),(5.6,'span.badge:has-text("Not yet")'),(7.0,'span.badge:has-text("1 held")'),(9.0,('a.row:has-text("Total DPS")',(0.25,0.5)))],
 'clicks':[9.2]})
SC['s4']=('Breakdown',10.4,{
 'caps':[(0.3,'<b>4</b>Breakdown: how the number is built, factor by factor.'),
         (3.7,'Every source, with the exact game stat it comes from.'),
         (6.9,'Held lines are named here, so nothing is silently left out.')],
 'ring':[(0.6,3.5,'section.panel:has-text("How it is built")'),(3.7,6.7,'section.panel:has-text("Increased damage")'),(6.9,9.6,'section.panel:has-text("Not counted here")')],
 'cursor':[(0,(900,600)),(1.8,'button.factor:has-text("Increased")'),(2.9,'button.factor:has-text("Crit multiplier")'),(4.5,'td:has-text("lightning_damage_+%") >> nth=0'),(5.7,'td:has-text("spell_damage_+%") >> nth=1'),(7.7,'a:has-text("Review held lines")')]})
INIT_IE=["""(()=>{const i=document.querySelector('input[aria-label="+ to maximum Life"]');i.value='92';const row=i.closest('div[style*="border-top"]');row.style.background='transparent';const b=row.querySelector('.badge');b.className='badge b-ok';b.textContent='Matched';row.querySelector('span.mono.muted').textContent='base_maximum_life';
const st=document.querySelector('header [role=status]');st.className='badge b-ok';st.textContent='Up to date';
const lr=[...document.querySelectorAll('aside .panel > div')].find(d=>d.firstElementChild&&d.firstElementChild.textContent==='Life');const sp=lr.children[1].children;sp[1].textContent='4,820';sp[2].textContent='±0';sp[2].style.color='#A3A9B3';})()"""]
SC['s5']=('ItemEditor',12.6,{
 'init':INIT_IE,
 'caps':[(0.3,'<b>5</b>Item editor: every line shows whether it was matched to game data.'),
         (3.1,'Change a value…'),
         (5.8,'…and see the effect on the build before you apply it.'),
         (8.1,'Held lines stay in the item and export exactly as written.'),
         (10.0,'Apply: the edit becomes one step you can undo.')],
 'ring':[(0.6,2.9,'div:has(> span > span.badge:has-text("Matched")):has-text("read from game data")'),(3.1,5.6,'div[style*="border-top"]:has(input[aria-label="+ to maximum Life"])'),(5.8,7.9,'section.panel:has-text("Impact of this edit")'),(8.1,9.8,'div[style*="border-top"]:has-text("Unknown Aura")')],
 'cursor':[(0,(1000,700)),(1.6,'span.badge:has-text("Adapted") >> nth=1'),(3.8,'input[aria-label="+ to maximum Life"]'),(6.6,('div:has(> span.muted:text-is("Life"))',(0.85,0.5))),(8.8,'span.badge:text-is("Held") >> nth=1'),(10.7,'button:has-text("Apply changes")')],
 'clicks':[3.9,10.9],
 'acts':[(4.0,"document.querySelector('input[aria-label=\"+ to maximum Life\"]').value=''"),
         (4.9,"""(()=>{const i=document.querySelector('input[aria-label="+ to maximum Life"]');const row=i.closest('div[style*="border-top"]');row.style.background='#1E2026';const b=row.querySelector('.badge');b.className='badge b-neutral';b.textContent='Edited';row.querySelector('span.mono.muted').textContent='base_maximum_life · was 92';const st=document.querySelector('header [role=status]');st.className='badge b-info';st.textContent='Recalculating…';})()"""),
         (5.6,"""(()=>{const st=document.querySelector('header [role=status]');st.className='badge b-ok';st.textContent='Up to date';const lr=[...document.querySelectorAll('aside .panel > div')].find(d=>d.firstElementChild&&d.firstElementChild.textContent==='Life');const sp=lr.children[1].children;sp[1].textContent='4,851';sp[2].textContent='+31';sp[2].style.color='#A3DDB2';})()"""),
         (11.0,"(()=>{const t=document.getElementById('ov-toast');t.textContent='Applied · Undo with Ctrl+Z';t.style.display='block'})()")],
 'type':[(4.15,4.8,'input[aria-label="+ to maximum Life"]','104')]})
SC['s6']=('AiApproval',12.4,{
 'caps':[(0.3,'<b>6</b>AI tools connect locally. Read-only unless you allow more.'),
         (3.5,'A suggested change arrives as a request you approve or decline.'),
         (6.5,'Exiled Studio calculates the effect itself, not the AI.'),
         (8.7,'Approve: it becomes one undoable step in your history.')],
 'ring':[(0.6,3.3,'section.panel:has-text("Claude Desktop"):has-text("Connected")'),(3.5,6.3,'section.panel:has-text("Change request")'),(6.5,8.5,'div:has(> span:text-is("Calculated by Exiled Studio, not by the AI"))')],
 'cursor':[(0,(900,650)),(1.8,'span.badge:has-text("Ask each time")'),(4.4,'span:text-is("Glyph Loop, Opal Ring")'),(5.5,'span:text-is("New rare, Opal Ring")'),(7.4,'span.badge:has-text("Chaos resistance")'),(9.5,'button:has-text("Approve change")')],
 'clicks':[9.7],
 'acts':[(9.9,"(()=>{const t=document.getElementById('ov-toast');t.textContent='Change applied · Undo with Ctrl+Z';t.style.display='block';document.querySelector('header .badge.b-info').style.display='none'})()")]})
SC['s7']=('End',4.2,{'showcur':False,'cursor':[(0,(800,450))]})
if __name__=='__main__':
    which=sys.argv[1]; only=[float(x) for x in sys.argv[2:]] or None
    page,dur,s=SC[which]; run(which,page,dur,s,only=only)
