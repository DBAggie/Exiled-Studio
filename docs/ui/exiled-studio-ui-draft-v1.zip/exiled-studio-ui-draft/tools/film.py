import sys, os, math, subprocess
from playwright.sync_api import sync_playwright
FPS=30
OVERLAY = """
(()=>{const s=document.createElement('style');s.textContent=`
.es{zoom:0.9;min-height:111.2vh !important}
#ov-ring{position:fixed;border:3px solid #7FB2E5;border-radius:12px;box-shadow:0 0 0 6px rgba(127,178,229,.18),0 0 28px rgba(127,178,229,.35);pointer-events:none;z-index:9000;opacity:0}
#ov-cap{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);max-width:1200px;padding:14px 26px;border-radius:14px;background:rgba(9,10,12,.94);border:1px solid #3A414C;color:#F3F1EC;font:600 23px/1.35 Inter,sans-serif;z-index:9100;box-shadow:0 10px 30px rgba(0,0,0,.5);text-align:center;opacity:0}
#ov-cap b{color:#E8A33D;margin-right:10px}
#ov-cur{position:fixed;left:0;top:0;width:28px;height:28px;z-index:9300;pointer-events:none;filter:drop-shadow(0 2px 3px rgba(0,0,0,.6))}
#ov-rip{position:fixed;border-radius:50%;border:3px solid #FFFFFF;z-index:9200;pointer-events:none;opacity:0}
#ov-fade{position:fixed;inset:0;background:#000;z-index:9900;pointer-events:none}
#ov-toast{position:fixed;right:28px;top:84px;padding:14px 18px;border-radius:10px;background:#1D2B22;border:1px solid #2C4A36;color:#A3DDB2;font:600 17px Inter,sans-serif;z-index:9050;display:none}`;
document.head.appendChild(s);
for(const id of ['ov-ring','ov-cap','ov-rip','ov-fade','ov-toast']){const d=document.createElement('div');d.id=id;document.body.appendChild(d)}
const c=document.createElement('div');c.id='ov-cur';c.innerHTML='<svg viewBox="0 0 24 24" width="28" height="28"><path d="M3 2l7.5 19 2.6-7.6L21 10.8z" fill="#fff" stroke="#111" stroke-width="1.4" stroke-linejoin="round"/></svg>';document.body.appendChild(c);
window.__set=(st)=>{
 const r=document.getElementById('ov-ring');
 if(st.ring){r.style.left=st.ring[0]+'px';r.style.top=st.ring[1]+'px';r.style.width=st.ring[2]+'px';r.style.height=st.ring[3]+'px';r.style.opacity=st.ringA}else r.style.opacity=0;
 const cap=document.getElementById('ov-cap'); if(cap.dataset.t!==st.cap){cap.dataset.t=st.cap;cap.innerHTML=st.cap} cap.style.opacity=st.capA;
 const cu=document.getElementById('ov-cur'); cu.style.display=st.cur?'block':'none'; if(st.cur){cu.style.transform=`translate(${st.cur[0]-3}px,${st.cur[1]-2}px)`}
 const rp=document.getElementById('ov-rip'); if(st.rip){const R=st.rip[2];rp.style.left=(st.rip[0]-R)+'px';rp.style.top=(st.rip[1]-R)+'px';rp.style.width=rp.style.height=(2*R)+'px';rp.style.opacity=st.rip[3]}else rp.style.opacity=0;
 document.getElementById('ov-fade').style.opacity=st.fade;
};})()
"""
def ease(x): x=max(0,min(1,x)); return x*x*(3-2*x)

def run(name, page_file, dur, script, outdir='scenes', only=None):
    with sync_playwright() as p:
        b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
        pg=b.new_page(viewport={'width':1600,'height':900},device_scale_factor=1.2)
        pg.goto(f'file:///home/claude/video/pages/{page_file}.html'); pg.evaluate(OVERLAY); pg.wait_for_timeout(150)
        boxes={}
        def box(sel):
            if sel not in boxes:
                bb=pg.locator(sel).first.bounding_box()
                if bb is None: raise SystemExit(f'no box {sel}')
                boxes[sel]=bb
            return boxes[sel]
        def pt(t):
            if isinstance(t,tuple) and isinstance(t[0],(int,float)): return t
            sel,(fx,fy)=(t,(0.5,0.5)) if isinstance(t,str) else t
            bb=box(sel); return (bb['x']+bb['width']*fx, bb['y']+bb['height']*fy)
        S=script
        for js in S.get('init',[]): pg.evaluate(js)
        acts=sorted(S.get('acts',[]),key=lambda a:a[0]); ai=0
        types=S.get('type',[])
        frames=range(int(dur*FPS)) if only is None else [int(t*FPS) for t in only]
        enc=None
        if only is None:
            os.makedirs(outdir,exist_ok=True); tmp=f'{outdir}/{name}.tmp.mp4'
            enc=subprocess.Popen(['ffmpeg','-loglevel','error','-y','-f','image2pipe','-framerate',str(FPS),'-c:v','mjpeg','-i','-','-c:v','libx264','-crf','18','-preset','veryfast','-pix_fmt','yuv420p','-r',str(FPS),tmp],stdin=subprocess.PIPE)
        for f in frames:
            t=f/FPS
            while ai<len(acts) and acts[ai][0]<=t:
                pg.evaluate(acts[ai][1]); boxes.clear(); ai+=1
            for (t0,t1,sel,text) in types:
                if t0<=t<=t1+0.05:
                    k=round(len(text)*ease((t-t0)/(t1-t0))) if t1>t0 else len(text)
                    pg.evaluate("([s,v])=>{const e=document.querySelector(s);e.value=v}",[sel,text[:k]])
            # cursor
            cur=None
            mv=S.get('cursor',[])
            if mv:
                pos=pt(mv[0][1]); 
                for (ta,tgt,*d) in mv[1:]:
                    d=d[0] if d else 0.7
                    p1=pt(tgt)
                    if t>=ta: pos=p1
                    elif t>ta-d:
                        k=ease((t-(ta-d))/d); pos=(pos[0]+(p1[0]-pos[0])*k,pos[1]+(p1[1]-pos[1])*k)
                    else: break
                cur=pos
            # ring
            ring=None; ringA=0
            for (r0,r1,sel) in S.get('ring',[]):
                if r0<=t<=r1:
                    bb=box(sel); pad=8
                    ring=[bb['x']-pad,bb['y']-pad,bb['width']+2*pad,bb['height']+2*pad]
                    ringA=min(ease((t-r0)/0.25),ease((r1-t)/0.25))
            # caption
            cap='';capA=0
            caps=S.get('caps',[])
            for i,(c0,txt) in enumerate(caps):
                c1=caps[i+1][0] if i+1<len(caps) else dur-0.5
                if c0<=t<c1:
                    cap=txt; capA=min(ease((t-c0)/0.25),ease((c1-t)/0.2)) if i+1<len(caps) else min(ease((t-c0)/0.25),ease((c1-t)/0.3))
            rip=None
            for tc in S.get('clicks',[]):
                if tc<=t<=tc+0.45 and cur:
                    k=(t-tc)/0.45; rip=[cur[0],cur[1],8+30*k,1-k]
            fade=max(1-ease(t/0.4), ease((t-(dur-0.45))/0.45))
            pg.evaluate('s=>__set(s)',{'ring':ring,'ringA':ringA,'cap':cap,'capA':capA,'cur':list(cur) if cur and S.get('showcur',True) else None,'rip':rip,'fade':fade})
            img=pg.screenshot(type='jpeg',quality=92)
            if enc: enc.stdin.write(img)
            else: open(f'test_{name}_{t:.1f}.jpg','wb').write(img)
        b.close()
        if enc:
            enc.stdin.close()
            if enc.wait()==0: os.replace(tmp,f'{outdir}/{name}.mp4')
            else: raise SystemExit('encode failed '+name)
