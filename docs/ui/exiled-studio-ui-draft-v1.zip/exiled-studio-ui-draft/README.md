# Exiled Studio: UI rough draft v1 (handoff package)

A package for continuing the UI design work for https://github.com/DBAggie/Exiled-Studio in a
future session.

**Start with `UI-DESIGN-BRIEF.md`.** It covers the product as understood, the visual language,
terminology, the screen inventory, every decision made so far, data-model implications and open
questions.

## Contents

| Path | What it is |
|---|---|
| `UI-DESIGN-BRIEF.md` | The design brief and decisions log. Read first. |
| `screenshots/` | Full-page PNGs of all 11 screens, plus extra states: stage menu open, Leveling stage, Skills table view |
| `rendered-html/` | Plain, self-contained HTML of each screen (open in a browser; fonts fall back to local ones) |
| `canvas-source/project/` | Editable source of the design canvas: one `.dc.html` per screen plus `canvas.json` (board layout, titles, notes) |
| `tools/` | Scripts used to build and render the screens (see below) |
| `video/exiled-studio-ui-walkthrough-v1.mp4` | 74 s walkthrough of screens 1–6. **Out of date**: uses the old term "held" and predates later screens |

## Live canvas

https://claude.ai/artifact/ECz5DeeNukjcxPEiPiCh9B (private to the owner). To continue editing it in
a future session, give Claude this link. The canvas holds the same files as `canvas-source/project/`.
If the live canvas has been edited since this package was made, it is the newer source.

To rebuild a canvas from this package instead, create a new Design canvas and publish the files in
`canvas-source/project/` (keep the paths, including `project/`).

## About the `.dc.html` format

Each screen is one self-contained "Design Component" page:

- markup inside `<x-dc>`;
- shared styles in `<helmet><style>`;
- a `<script type="text/x-dc" data-dc-script>` block whose `class Component extends DCLogic`
  returns template values from `renderVals()`.

Templates use `{{path}}` holes, `<sc-for list= as=>` loops and `<sc-if value=>` branches.
Interactive screens keep state with `this.setState`. `data-props` declares the Tweaks controls
(accent colour, stage, menu open, Cards/Table view, quick-look).

## Tools

All are Python 3; rendering needs Node and Playwright with Chrome.

- `tools/render_dc.py SRC.dc.html OUT.html ['{"prop":"value"}']` renders a `.dc.html` to plain HTML
  by running its `renderVals()` in Node and expanding the template.
  - Optional JSON props, for example `'{"stage":"Leveling","menuOpen":false}'` for Equipment, or
    `'{"view":"Table"}'` for Skills.
- `tools/build_skills2.py` regenerates `SkillsA.dc.html` and `SkillGroup.dc.html` into
  `canvas-source/project/` from `skills.py` (shared shell and gem data) and `build_skills.py`
  (section bodies).
  - Afterwards, re-add `open="open"` to the Export `<details>` in `SkillsA.dc.html` if you want the
    menu shown open on the canvas.
  - Do not run `build_skills.py` directly: it would recreate the dropped variations B, C and D.
- `tools/export.py` holds the Export dropdown markup and CSS, and a `patch()` helper that was used
  to add it to every header.
- `tools/film.py` and `tools/scenes.py` are the video engine: Playwright screenshots, a scripted
  cursor, highlight rings and captions, piped to ffmpeg.
  - Paths inside point at the original working folder (`/home/claude/video/pages`). Re-render the
    pages with `render_dc.py` and adjust those paths before re-filming.

All data in the screens is sample data for layout only.
